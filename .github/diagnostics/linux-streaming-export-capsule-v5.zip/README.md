# Linux streaming source-view export capsule v5

This capsule measures the candidate public `build_source_view` implementation
with module SHA-256 `9ab8afb151dd1c2c7fe0e3017267777ffcc89236ec92ef90e1869d3b12d2dabd` (59273 bytes). On Linux with
Python 3.11 or newer, run:

```bash
python3 runner.py --output serialized-export-receipt.json
```

The unchanged v4 runner verifies the frozen module and source identities before
execution. H25 then H02 run in fresh children, each with exact 3 GiB `RLIMIT_AS`
and a 180-second parent wall. H02 is held after any H25 failure. Execution
requires at least 4 GiB free and provides no retry, fallback, network access,
provider call, model call, SEC fetch, or limit increase.

Each child calls the public `build_source_view` once. A success must retain
exactly four regular files: `compact.txt`, `manifest.json`, `reader.txt`, and
`source-view.json`. Child and parent read only the small manifest and stream-hash
the output files; the parent never loads the large projection. A nonzero child
exit fails even if stdout claims success. Failures retain a streamed partial
inventory, last phase, exit or signal, elapsed time, disk space, peak RSS when
available, and up to eight deepest traceback frames.

This candidate capsule is preparation, not an execution result, production
release, capacity pass, or semantic acceptance. A Linux success would establish
only that these exact two frozen direct-primary sources can be exported by this
exact candidate module under this one resource contract. It would not attest
historical SGML-member identity, all-member capacity, semantic completeness,
source quality, programme admission, or downstream review acceptance.
