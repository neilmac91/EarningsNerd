#!/usr/bin/env python3
"""Linux-only, bounded full source-view export for frozen H25/H02."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback
from typing import Any


BASE = Path(__file__).resolve().parent
MANIFEST_PATH = BASE / "manifest.json"
EXPORT_ROOT = BASE / "serialized-views"
ADDRESS_SPACE_BYTES = 3 * 1024**3
MINIMUM_FREE_BYTES = 4 * 1024**3
WALL_SECONDS = 180
ORDER = ("H25", "H02")
EXPECTED_LEAVES = ("compact.txt", "manifest.json", "reader.txt", "source-view.json")
SHA256 = re.compile(r"[0-9a-f]{64}")
EXPECTED_MODULE = {
    "path": "acceptance_source_view.py",
    "bytes": 59273,
    "sha256": "9ab8afb151dd1c2c7fe0e3017267777ffcc89236ec92ef90e1869d3b12d2dabd",
}
EXPECTED_SOURCES = {
    "H02": {
        "path": "sources/H02/duk-20251231.htm",
        "bytes": 16080286,
        "sha256": "25141df6945a6def54f02ecda3705ea44823a9624761c01571dd040b1e61e5f9",
    },
    "H25": {
        "path": "sources/H25/hsbc-20251231.htm",
        "bytes": 57158558,
        "sha256": "08f3a9c524be807db51302faffee034992d9c00c90013bb239b3a940e973539c",
        "source_form": "frozen direct primary",
        "sgml_member_byte_difference": 111,
    },
}


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_and_verify_manifest() -> dict[str, Any]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    if manifest.get("execution_order") != list(ORDER):
        raise RuntimeError("manifest execution order is not frozen H25 then H02")
    if manifest.get("limits") != {
        "child_address_space_bytes": ADDRESS_SPACE_BYTES,
        "child_wall_seconds": WALL_SECONDS,
        "minimum_free_bytes": MINIMUM_FREE_BYTES,
        "minimum_python": "3.11",
        "platform": "linux",
    }:
        raise RuntimeError("manifest limits differ from runner limits")
    if manifest.get("module") != EXPECTED_MODULE or manifest.get("sources") != EXPECTED_SOURCES:
        raise RuntimeError("manifest file identities differ from runner trust anchors")
    if manifest.get("expected_output_leaves") != list(EXPECTED_LEAVES):
        raise RuntimeError("manifest output leaves differ from runner trust anchors")
    records = [manifest["module"], *(manifest["sources"][name] for name in ORDER)]
    for record in records:
        path = BASE / record["path"]
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"missing or unsafe capsule file: {record['path']}")
        if path.stat().st_size != record["bytes"] or _sha256(path) != record["sha256"]:
            raise RuntimeError(f"capsule file identity mismatch: {record['path']}")
    return manifest


def _base_receipt(manifest: dict[str, Any] | None) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "kind": "e7_linux_source_view_serialized_export_receipt",
        "started_at": _utc_now(),
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "operation": "acceptance_source_view.build_source_view",
        "limits": {
            "child_address_space_bytes": ADDRESS_SPACE_BYTES,
            "child_wall_seconds": WALL_SECONDS,
            "minimum_free_bytes": MINIMUM_FREE_BYTES,
        },
        "manifest_sha256": _sha256(MANIFEST_PATH) if MANIFEST_PATH.is_file() else None,
        "manifest": manifest,
        "results": [],
        "held": [],
        "admission_approved": False,
        "semantic_review_attested": False,
        "network_calls": 0,
        "provider_calls": 0,
        "model_calls": 0,
        "retries": 0,
    }


def _write_receipt(path: Path, receipt: dict[str, Any]) -> None:
    receipt["finished_at"] = _utc_now()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _traceback_frames(exc: BaseException) -> list[dict[str, Any]]:
    try:
        return [
            {"function": frame.name, "line": frame.lineno}
            for frame in traceback.extract_tb(exc.__traceback__, limit=-8)
        ]
    except MemoryError:
        return []


def _linux_resource_module() -> Any:
    if sys.platform != "linux":
        raise RuntimeError("refusing execution: this capsule requires Linux")
    if sys.version_info < (3, 11):
        raise RuntimeError("refusing execution: this capsule requires Python 3.11 or newer")
    try:
        import resource
    except ImportError as exc:
        raise RuntimeError("refusing execution: resource limits are unavailable") from exc
    if not hasattr(resource, "RLIMIT_AS"):
        raise RuntimeError("refusing execution: RLIMIT_AS is unavailable")
    _soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    if hard != resource.RLIM_INFINITY and hard < ADDRESS_SPACE_BYTES:
        raise RuntimeError("refusing execution: inherited RLIMIT_AS hard limit is below 3 GiB")
    return resource


def _limit_child() -> None:
    import resource

    resource.setrlimit(resource.RLIMIT_AS, (ADDRESS_SPACE_BYTES, ADDRESS_SPACE_BYTES))


def _entry_record(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"name": path.name}
    mode = path.lstat().st_mode
    if stat.S_ISLNK(mode):
        record["type"] = "symlink"
    elif stat.S_ISREG(mode):
        record.update({"type": "file", "bytes": path.stat().st_size, "sha256": _sha256(path)})
    elif stat.S_ISDIR(mode):
        record["type"] = "directory"
    else:
        record["type"] = "other"
    return record


def _partial_inventory(output: Path) -> dict[str, Any]:
    if output.is_symlink():
        return {"path": output.name, "type": "symlink", "entries": []}
    if not output.exists():
        return {"path": output.name, "type": "absent", "entries": []}
    if not output.is_dir():
        return {"path": output.name, "type": "non_directory", "entries": []}
    return {
        "path": output.name,
        "type": "directory",
        "entries": [_entry_record(path) for path in sorted(output.iterdir(), key=lambda item: item.name)],
    }


def _verify_export(output: Path, source_record: dict[str, Any]) -> dict[str, Any]:
    inventory = _partial_inventory(output)
    entries = inventory["entries"]
    if inventory["type"] != "directory":
        raise ValueError("export output is not a regular directory")
    if [entry["name"] for entry in entries] != list(EXPECTED_LEAVES):
        raise ValueError("export output does not contain exactly the four expected leaves")
    if any(entry["type"] != "file" for entry in entries):
        raise ValueError("export output contains a non-regular file or symlink")
    manifest_path = output / "manifest.json"
    if manifest_path.stat().st_size > 65536:
        raise ValueError("export manifest exceeds the small-manifest read limit")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if type(manifest.get("schema_version")) is not int or manifest["schema_version"] != 1:
        raise ValueError("export manifest schema version is invalid")
    if manifest.get("kind") != "e7_offline_html_source_view_bundle":
        raise ValueError("export manifest kind is invalid")
    expected_source = {
        "path": source_record["path"],
        "bytes": source_record["bytes"],
        "sha256": source_record["sha256"],
    }
    if manifest.get("source") != expected_source:
        raise ValueError("export manifest source identity differs")
    if manifest.get("semantic_coverage_attested") is not False:
        raise ValueError("export manifest unexpectedly attests semantic coverage")
    expected_roles = {
        "compact_text": "compact.txt",
        "projection": "source-view.json",
        "reader": "reader.txt",
    }
    if set(manifest.get("files", {})) != set(expected_roles):
        raise ValueError("export manifest file roles differ")
    by_name = {entry["name"]: entry for entry in entries}
    for role, leaf in expected_roles.items():
        declared = manifest["files"][role]
        if set(declared) != {"path", "bytes", "sha256"} or declared.get("path") != leaf:
            raise ValueError(f"export manifest {role} record is invalid")
        if type(declared.get("bytes")) is not int or declared["bytes"] < 0:
            raise ValueError(f"export manifest {role} byte count is invalid")
        if type(declared.get("sha256")) is not str or SHA256.fullmatch(declared["sha256"]) is None:
            raise ValueError(f"export manifest {role} SHA-256 is invalid")
        actual = by_name[leaf]
        if actual["bytes"] != declared["bytes"] or actual["sha256"] != declared["sha256"]:
            raise ValueError(f"export manifest {role} size/hash differs from streamed file")
    return {"manifest": manifest, "inventory": inventory}


def _phase_from_stderr(stderr: str) -> str | None:
    phases = [line.removeprefix("CAPSULE_PHASE ") for line in stderr.splitlines() if line.startswith("CAPSULE_PHASE ")]
    return phases[-1] if phases else None


def _run_worker(name: str, source_record: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    output = EXPORT_ROOT / name
    disk_before = shutil.disk_usage(BASE).free
    if disk_before < MINIMUM_FREE_BYTES:
        return {
            "source": name,
            "status": "refused_insufficient_disk",
            "elapsed_seconds_parent": round(time.monotonic() - started, 6),
            "disk_free_bytes_before": disk_before,
            "minimum_free_bytes": MINIMUM_FREE_BYTES,
            "partial_output": _partial_inventory(output),
        }
    command = [sys.executable, str(Path(__file__).resolve()), "--worker", name]
    process = subprocess.Popen(
        command,
        cwd=BASE,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
        preexec_fn=_limit_child,
    )
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=WALL_SECONDS)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
    elapsed = round(time.monotonic() - started, 6)
    common = {
        "source": name,
        "elapsed_seconds_parent": elapsed,
        "exit_code": process.returncode,
        "disk_free_bytes_before": disk_before,
        "disk_free_bytes_after": shutil.disk_usage(BASE).free,
        "last_phase_from_stderr": _phase_from_stderr(stderr),
    }
    if stderr:
        common["stderr_sha256"] = hashlib.sha256(stderr.encode()).hexdigest()
        common["stderr_bytes"] = len(stderr.encode())
    if timed_out:
        return {
            **common,
            "status": "wall_limit_exceeded",
            "partial_output": _partial_inventory(output),
        }
    lines = [line for line in stdout.splitlines() if line.strip()]
    result: dict[str, Any] | None = None
    if len(lines) == 1:
        try:
            candidate = json.loads(lines[0])
        except json.JSONDecodeError:
            candidate = None
        if isinstance(candidate, dict) and candidate.get("source") == name:
            result = candidate
    if result is None:
        return {
            **common,
            "status": "terminated_without_valid_receipt",
            "stdout_bytes": len(stdout.encode()),
            "stdout_sha256": hashlib.sha256(stdout.encode()).hexdigest(),
            "partial_output": _partial_inventory(output),
        }
    result.update(common)
    if result.get("status") == "ok" and process.returncode != 0:
        result.update({
            "status": "abnormal_exit",
            "claimed_worker_status": "ok",
            "partial_output": _partial_inventory(output),
        })
        return result
    if result.get("status") != "ok":
        result["partial_output"] = _partial_inventory(output)
        return result
    try:
        parent_verification = _verify_export(output, source_record)
        if parent_verification != result.get("export"):
            raise ValueError("parent export verification differs from worker verification")
        result["export"] = parent_verification
    except BaseException as exc:
        result.update({
            "status": "output_verification_failed",
            "error_type": type(exc).__name__,
            "error": str(exc)[:500],
            "partial_output": _partial_inventory(output),
        })
    return result


def _worker(name: str) -> int:
    started = time.monotonic()
    result: dict[str, Any] = {"source": name, "status": "error"}
    phase = "worker_initialization"
    resource_module: Any | None = None
    observed_limits: tuple[int, int] | None = None
    try:
        resource_module = _linux_resource_module()
        soft, hard = resource_module.getrlimit(resource_module.RLIMIT_AS)
        observed_limits = (soft, hard)
        if (soft, hard) != (ADDRESS_SPACE_BYTES, ADDRESS_SPACE_BYTES):
            raise RuntimeError("worker does not have the exact 3 GiB RLIMIT_AS")
        manifest = _load_and_verify_manifest()
        if name not in ORDER:
            raise RuntimeError("unknown source identity")
        source_record = manifest["sources"][name]
        source = Path(source_record["path"])
        output = EXPORT_ROOT / name
        if output.exists() or output.is_symlink():
            raise RuntimeError("worker export path already exists or is a symlink")
        from acceptance_source_view import build_source_view

        phase = "before_build_source_view"
        print(f"CAPSULE_PHASE {phase}", file=sys.stderr, flush=True)
        returned_manifest = build_source_view(
            source=source,
            expected_sha256=source_record["sha256"],
            expected_bytes=source_record["bytes"],
            output=output,
        )
        phase = "before_stream_verification"
        print(f"CAPSULE_PHASE {phase}", file=sys.stderr, flush=True)
        export = _verify_export(output, source_record)
        if returned_manifest != export["manifest"]:
            raise ValueError("returned manifest differs from the retained manifest")
        phase = "complete"
        print(f"CAPSULE_PHASE {phase}", file=sys.stderr, flush=True)
        result = {"source": name, "status": "ok", "phase": phase, "export": export}
    except MemoryError as exc:
        result = {
            "source": name,
            "status": "memory_limit_exceeded",
            "phase": phase,
            "traceback": _traceback_frames(exc),
        }
    except BaseException as exc:
        result = {
            "source": name,
            "status": "error",
            "error_type": type(exc).__name__,
            "error": str(exc)[:500],
            "phase": phase,
            "traceback": _traceback_frames(exc),
        }
    if observed_limits is not None:
        result["rlimit_as_soft_bytes"] = observed_limits[0]
        result["rlimit_as_hard_bytes"] = observed_limits[1]
    if resource_module is not None:
        result["max_rss_bytes"] = int(resource_module.getrusage(resource_module.RUSAGE_SELF).ru_maxrss * 1024)
    result["elapsed_seconds_worker"] = round(time.monotonic() - started, 6)
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0 if result["status"] == "ok" else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("serialized-export-receipt.json"))
    parser.add_argument("--worker", choices=ORDER, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        return _worker(args.worker)

    manifest: dict[str, Any] | None = None
    try:
        manifest = _load_and_verify_manifest()
    except BaseException as exc:
        receipt = _base_receipt(None)
        receipt["status"] = "refused"
        receipt["reason"] = f"{type(exc).__name__}: {str(exc)[:500]}"
        _write_receipt(args.output, receipt)
        return 2

    receipt = _base_receipt(manifest)
    try:
        _linux_resource_module()
        if EXPORT_ROOT.exists() or EXPORT_ROOT.is_symlink():
            raise RuntimeError("refusing execution: serialized-views must not already exist")
        free = shutil.disk_usage(BASE).free
        receipt["disk_free_bytes_before"] = free
        if free < MINIMUM_FREE_BYTES:
            raise RuntimeError("refusing execution: output filesystem has less than 4 GiB free")
        EXPORT_ROOT.mkdir()
        for index, name in enumerate(ORDER):
            result = _run_worker(name, manifest["sources"][name])
            receipt["results"].append(result)
            if result.get("status") != "ok":
                receipt["status"] = "failed"
                for held in ORDER[index + 1 :]:
                    receipt["held"].append({"source": held, "reason": f"held after {name} failure"})
                break
        else:
            receipt["status"] = "ok"
        receipt["disk_free_bytes_after"] = shutil.disk_usage(BASE).free
    except BaseException as exc:
        receipt["status"] = "refused"
        receipt["reason"] = f"{type(exc).__name__}: {str(exc)[:500]}"
        completed = {item["source"] for item in receipt["results"]}
        for name in ORDER:
            if name not in completed:
                receipt["held"].append({"source": name, "reason": "held after runner refusal"})
    _write_receipt(args.output, receipt)
    return 0 if receipt["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
