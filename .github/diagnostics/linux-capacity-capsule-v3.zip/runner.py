#!/usr/bin/env python3
"""Linux-only, bounded source-view capacity measurement for frozen H25/H02."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
from typing import Any


BASE = Path(__file__).resolve().parent
MANIFEST_PATH = BASE / "manifest.json"
ADDRESS_SPACE_BYTES = 3 * 1024**3
WALL_SECONDS = 180
ORDER = ("H25", "H02")
EXPECTED_MODULE = {
    "path": "acceptance_source_view.py",
    "bytes": 58613,
    "sha256": "be3142802e443b92e38bf4723e8c98d7067732d80cc2249ae4d9d14f276520c7",
}
EXPECTED_SOURCES = {
    "H02": {
        "path": "sources/H02/duk-20251231.htm",
        "bytes": 16080286,
        "sha256": "25141df6945a6def54f02ecda3705ea44823a9624761c01571dd040b1e61e5f9",
    },
    "H25": {
        "path": "sources/H25/hsbc-20251231.htm",
        "bytes": 57158558,
        "sha256": "08f3a9c524be807db51302faffee034992d9c00c90013bb239b3a940e973539c",
        "source_form": "frozen direct primary",
        "sgml_member_byte_difference": 111,
    },
}


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_and_verify_manifest() -> dict[str, Any]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    if manifest.get("execution_order") != list(ORDER):
        raise RuntimeError("manifest execution order is not frozen H25 then H02")
    if manifest.get("limits") != {
        "child_address_space_bytes": ADDRESS_SPACE_BYTES,
        "child_wall_seconds": WALL_SECONDS,
        "minimum_python": "3.11",
        "platform": "linux",
    }:
        raise RuntimeError("manifest limits differ from runner limits")
    if manifest.get("module") != EXPECTED_MODULE or manifest.get("sources") != EXPECTED_SOURCES:
        raise RuntimeError("manifest file identities differ from runner trust anchors")
    records = [manifest["module"], *(manifest["sources"][name] for name in ORDER)]
    for record in records:
        path = BASE / record["path"]
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"missing or unsafe capsule file: {record['path']}")
        if path.stat().st_size != record["bytes"] or _sha256(path) != record["sha256"]:
            raise RuntimeError(f"capsule file identity mismatch: {record['path']}")
    return manifest


def _base_receipt(manifest: dict[str, Any] | None) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "kind": "e7_linux_source_view_capacity_receipt",
        "started_at": _utc_now(),
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "limits": {
            "child_address_space_bytes": ADDRESS_SPACE_BYTES,
            "child_wall_seconds": WALL_SECONDS,
        },
        "manifest_sha256": _sha256(MANIFEST_PATH) if MANIFEST_PATH.is_file() else None,
        "manifest": manifest,
        "results": [],
        "held": [],
        "admission_approved": False,
        "semantic_review_attested": False,
        "network_calls": 0,
        "provider_calls": 0,
        "model_calls": 0,
    }


def _write_receipt(path: Path, receipt: dict[str, Any]) -> None:
    receipt["finished_at"] = _utc_now()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _traceback_frames(exc: BaseException) -> list[dict[str, Any]]:
    try:
        return [
            {"function": frame.name, "line": frame.lineno}
            for frame in traceback.extract_tb(exc.__traceback__, limit=-8)
        ]
    except MemoryError:
        return []


def _linux_resource_module() -> Any:
    if sys.platform != "linux":
        raise RuntimeError("refusing execution: this capsule requires Linux")
    if sys.version_info < (3, 11):
        raise RuntimeError("refusing execution: this capsule requires Python 3.11 or newer")
    try:
        import resource
    except ImportError as exc:
        raise RuntimeError("refusing execution: resource limits are unavailable") from exc
    if not hasattr(resource, "RLIMIT_AS"):
        raise RuntimeError("refusing execution: RLIMIT_AS is unavailable")
    _soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    if hard != resource.RLIM_INFINITY and hard < ADDRESS_SPACE_BYTES:
        raise RuntimeError("refusing execution: inherited RLIMIT_AS hard limit is below 3 GiB")
    return resource


def _limit_child() -> None:
    import resource

    resource.setrlimit(resource.RLIMIT_AS, (ADDRESS_SPACE_BYTES, ADDRESS_SPACE_BYTES))


def _run_worker(name: str) -> dict[str, Any]:
    started = time.monotonic()
    command = [sys.executable, str(Path(__file__).resolve()), "--worker", name]
    process = subprocess.Popen(
        command,
        cwd=BASE,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
        preexec_fn=_limit_child,
    )
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=WALL_SECONDS)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
    elapsed = round(time.monotonic() - started, 6)
    if timed_out:
        return {
            "source": name,
            "status": "wall_limit_exceeded",
            "elapsed_seconds": elapsed,
            "exit_code": process.returncode,
        }
    lines = [line for line in stdout.splitlines() if line.strip()]
    if len(lines) == 1:
        try:
            result = json.loads(lines[0])
        except json.JSONDecodeError:
            result = None
        if isinstance(result, dict) and result.get("source") == name:
            result["elapsed_seconds_parent"] = elapsed
            result["exit_code"] = process.returncode
            if stderr:
                result["stderr_sha256"] = hashlib.sha256(stderr.encode()).hexdigest()
                result["stderr_bytes"] = len(stderr.encode())
            return result
    return {
        "source": name,
        "status": "terminated_without_valid_receipt",
        "elapsed_seconds": elapsed,
        "exit_code": process.returncode,
        "stdout_bytes": len(stdout.encode()),
        "stderr_bytes": len(stderr.encode()),
        "stdout_sha256": hashlib.sha256(stdout.encode()).hexdigest(),
        "stderr_sha256": hashlib.sha256(stderr.encode()).hexdigest(),
    }


def _worker(name: str) -> int:
    started = time.monotonic()
    result: dict[str, Any] = {"source": name, "status": "error"}
    phase = "worker_initialization"
    resource_module: Any | None = None
    observed_limits: tuple[int, int] | None = None
    try:
        resource_module = _linux_resource_module()
        soft, hard = resource_module.getrlimit(resource_module.RLIMIT_AS)
        observed_limits = (soft, hard)
        if (soft, hard) != (ADDRESS_SPACE_BYTES, ADDRESS_SPACE_BYTES):
            raise RuntimeError("worker does not have the exact 3 GiB RLIMIT_AS")
        manifest = _load_and_verify_manifest()
        if name not in ORDER:
            raise RuntimeError("unknown source identity")
        source_record = manifest["sources"][name]
        raw = (BASE / source_record["path"]).read_bytes()
        from acceptance_source_view import project_html, verify_projection

        phase = "before_project_html"
        projection = project_html(raw)
        phase = "before_outer_verify_projection"
        verify_projection(raw, projection)
        phase = "complete"
        result = {
            "source": name,
            "status": "ok",
            "phase": phase,
            "source_bytes": len(raw),
            "source_sha256": projection["source_sha256"],
            "compact_text_bytes": len(projection["compact_text"].encode("utf-8")),
            "compact_text_sha256": projection["compact_text_sha256"],
            "counts": {
                key: len(projection[key])
                for key in ("events", "attributes", "units", "elements", "tables", "images", "exclusions")
            },
        }
    except MemoryError as exc:
        result = {
            "source": name,
            "status": "memory_limit_exceeded",
            "phase": phase,
            "traceback": _traceback_frames(exc),
        }
    except BaseException as exc:
        result = {
            "source": name,
            "status": "error",
            "error_type": type(exc).__name__,
            "error": str(exc)[:500],
            "phase": phase,
            "traceback": _traceback_frames(exc),
        }
    if observed_limits is not None:
        result["rlimit_as_soft_bytes"] = observed_limits[0]
        result["rlimit_as_hard_bytes"] = observed_limits[1]
    if resource_module is not None:
        result["max_rss_bytes"] = int(
            resource_module.getrusage(resource_module.RUSAGE_SELF).ru_maxrss * 1024
        )
    result["elapsed_seconds_worker"] = round(time.monotonic() - started, 6)
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0 if result["status"] == "ok" else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("capacity-receipt.json"))
    parser.add_argument("--worker", choices=ORDER, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        return _worker(args.worker)

    manifest: dict[str, Any] | None = None
    try:
        manifest = _load_and_verify_manifest()
    except BaseException as exc:
        receipt = _base_receipt(None)
        receipt["status"] = "refused"
        receipt["reason"] = f"{type(exc).__name__}: {str(exc)[:500]}"
        _write_receipt(args.output, receipt)
        return 2

    receipt = _base_receipt(manifest)
    try:
        _linux_resource_module()
        for index, name in enumerate(ORDER):
            result = _run_worker(name)
            receipt["results"].append(result)
            if result.get("status") != "ok":
                receipt["status"] = "failed"
                for held in ORDER[index + 1 :]:
                    receipt["held"].append({"source": held, "reason": f"held after {name} failure"})
                break
        else:
            receipt["status"] = "ok"
    except BaseException as exc:
        receipt["status"] = "refused"
        receipt["reason"] = f"{type(exc).__name__}: {str(exc)[:500]}"
        completed = {item["source"] for item in receipt["results"]}
        for name in ORDER:
            if name not in completed:
                receipt["held"].append({"source": name, "reason": "held after runner refusal"})
    _write_receipt(args.output, receipt)
    return 0 if receipt["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
