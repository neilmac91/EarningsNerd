# Linux source-view ASCII-offset diagnostic capsule v3

From this extracted directory, on Linux with Python 3.11 or newer, run:

```bash
python3 runner.py --output capacity-receipt.json
```

The runner verifies the diagnostic parser module and both source files against identities embedded in the runner before execution. The outer ZIP SHA-256 pins the runner, manifest, README, module, and sources as one package. Each child gets an exact 3 GiB `RLIMIT_AS` and a 180-second hard wall. The runner records the observed child limit, Linux peak RSS, the last phase marker set before calling `project_html` or the runner's outer `verify_projection`, and at most eight traceback function/line frames without locals or source text. It runs H25 first and starts H02 only if H25 completes both calls. Missing limits, non-Linux systems, old Python, source drift, timeout, memory exhaustion, or validation failure fail closed; there is no unbounded fallback.

This candidate changes only ASCII character-to-byte offset storage to an identity `range` and releases parser-only state after `finish`; non-ASCII offset construction remains the released Python-integer-list algorithm. It is an experiment, not a production fix or a capacity result until executed on Linux. The capsule measures only whether this candidate can construct and verify an in-memory projection of two named frozen primary sources within those limits. It performs no network, SEC, model, or provider calls. It does not attest semantic review, source quality, programme admission, or browser rendering. H25 is the frozen direct primary (`08f3a9c…539c`); it differs by 111 bytes from the corresponding SGML member, so this run is not evidence about that member or other filing members.
