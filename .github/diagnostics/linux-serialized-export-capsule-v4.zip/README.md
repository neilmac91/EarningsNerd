# Linux full source-view export capsule v4

From this extracted directory, on Linux with Python 3.11 or newer, run:

```bash
python3 runner.py --output serialized-export-receipt.json
```

The runner verifies its unchanged released `acceptance_source_view.py` and both frozen source files against embedded byte counts and SHA-256 identities. Each fresh child receives an exact 3 GiB `RLIMIT_AS` and a 180-second parent-enforced hard wall. The output filesystem must have at least 4 GiB free before the first child. There is no retry, fallback, network access, provider call, model call, SEC fetch, or limit increase.

H25 runs first. The child calls the public `build_source_view` API once. If it returns, the child and parent independently read only the small manifest and stream-hash the output files. A success requires exactly four regular, non-symlink leaves: `compact.txt`, `manifest.json`, `reader.txt`, and `source-view.json`. Declared sizes and hashes must match the streamed files, the source identity must remain exact, and `semantic_coverage_attested` must remain false. The full four-file directory is retained. H02 starts in a fresh child only after H25 passes every check.

On failure, the receipt records elapsed time, exit or signal, disk space before and after, the last emitted phase when available, up to eight deepest traceback frames without locals or source text, and a streamed inventory of any partial output. A nonzero process exit is an abnormal failure even if stdout contains a syntactically valid `ok` receipt. H02 is held after any H25 failure. The runner refuses pre-existing or symlinked output paths and never loads the large serialized projection back into the parent.

This is a prepared diagnostic package, not an execution result or capacity pass. A future Linux success would establish only that these two exact frozen direct-primary sources can be exported by this released API under one 3 GiB/180-second contract. It would not attest semantic completeness, historical SGML-member identity, all-member capacity, source quality, programme admission, or downstream review acceptance. H25 differs by 111 bytes from the retained SGML member.
